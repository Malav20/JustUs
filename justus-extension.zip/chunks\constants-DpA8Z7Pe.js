const s={LIVEKIT_WS_URL:"wss://justus-0q7zbww8.livekit.cloud",WEB_API_URL:"https://just-us-web.vercel.app"};export{s as C};
