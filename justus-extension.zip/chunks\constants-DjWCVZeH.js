const s={LIVEKIT_WS_URL:"wss://justus-0q7zbww8.livekit.cloud",WEB_API_URL:"http://localhost:3000"};export{s as C};
